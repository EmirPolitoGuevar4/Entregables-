const test = require('node:test');
const assert = require('node:assert');

const { handleNewItem, deleteItem, updateItem } = require('../inventory.js');
let inventory = {};
const newQuantity = 10;
const newItem = 'apples';
inventory = handleNewItem(inventory, newItem, newQuantity);


test("Nuevo artículo fue agregado", () => {
  assert.equal(inventory.hasOwnProperty(newItem), true);
});

test("La cantidad del artículo es correcta", () => {
  assert.equal(inventory[newItem], newQuantity);
});




//PRUEBAS AGREGADAS

// Eliminar un artículo del inventario
test("Eliminar un artículo del inventario", () => {
  inventory = deleteItem(inventory, newItem);
  assert.equal(inventory.hasOwnProperty(newItem), false);
});

// Intentar eliminar un artículo que no existe
test("Eliminar un artículo que no existe", () => {
  const item = 'bananas';
  const originalInventory = { ...inventory };
  inventory = deleteItem(inventory, item);
  assert.deepEqual(inventory, originalInventory);
});

// Actualizar la cantidad de un artículo existente
test("Actualizar la cantidad de un artículo", () => {
  const updatedQuantity = 20;
  inventory = handleNewItem(inventory, newItem, updatedQuantity);
  assert.equal(inventory[newItem], updatedQuantity);
});

// Intentar actualizar un artículo que no existe
test("Actualizar un artículo que no existe", () => {
  const item = 'bananas';
  const updatedQuantity = 15;
  const originalInventory = { ...inventory };
  inventory = updateItem(inventory, item, updatedQuantity);
  assert.deepEqual(inventory, originalInventory);
});

// Ver todo el inventario
test("Ver inventario completo", () => {
  console.log("\nInventario:", inventory);
  assert.deepEqual(inventory, { [newItem]: 20 });
});






test("Test que fallará", () => {
  assert.equal(true, true); // (true, true) para que no marque error
});
